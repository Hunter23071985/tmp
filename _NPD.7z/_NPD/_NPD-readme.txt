JEDEC/ONFI NAND parameter page decoder
_NPD <filename.bin> [level][t]
level:
0 - short
2 - all field
t - save to file filename.bin.txt

example:
_NPD s11-bics3-613-sectA7.bin 2
_NPD s11-bics3-613-sectA7.bin t
_NPD s11-bics3-613-sectA7.bin 0t
